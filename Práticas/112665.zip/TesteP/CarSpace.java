package TesteP;

public class CarSpace extends CampingSpace {

    public CarSpace(String localizaçao, int[] dimensoes, double price) {
        super(localizaçao, dimensoes, price);
        this.setDuracao(3*30);
    }
    

}
