package TesteP;

public enum ClientType{
    NORMAL,MEMBER;
}