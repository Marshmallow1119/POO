package TesteP;

import java.util.Arrays;

public class CampingSpace {
    private String localizaçao;
    private int[] dimensoes;
    private double price;
    private int duracao;
    private String tipo;


    public CampingSpace(String localizaçao, int[] dimensoes, double price) {
        this.localizaçao = localizaçao;
        this.dimensoes = dimensoes;
        this.price = price;
        
    }


    public String getLocalizaçao() {
        return localizaçao;
    }
    public void setLocalizaçao(String localizaçao) {
        this.localizaçao = localizaçao;
    }
    public int[] getDimensoes() {
        return dimensoes;
    }
    public void setDimensoes(int[] dimensoes) {
        this.dimensoes = dimensoes;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public int getDuracao() {
        return duracao;
    }
    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }


    

    @Override
    public String toString() {
        return "CampingSpace [localizaçao=" + localizaçao + ", dimensoes=" + Arrays.toString(dimensoes) + ", price="
                + price + ", duracao=" + duracao + "]";
    }


    public void getTipo(){
        this.getTipo();
    }


    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((localizaçao == null) ? 0 : localizaçao.hashCode());
        result = prime * result + Arrays.hashCode(dimensoes);
        long temp;
        temp = Double.doubleToLongBits(price);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + duracao;
        result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CampingSpace other = (CampingSpace) obj;
        if (localizaçao == null) {
            if (other.localizaçao != null)
                return false;
        } else if (!localizaçao.equals(other.localizaçao))
            return false;
        if (!Arrays.equals(dimensoes, other.dimensoes))
            return false;
        if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
            return false;
        if (duracao != other.duracao)
            return false;
        if (tipo == null) {
            if (other.tipo != null)
                return false;
        } else if (!tipo.equals(other.tipo))
            return false;
        return true;
    }
   

}
