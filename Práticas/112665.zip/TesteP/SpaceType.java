package TesteP;

public enum SpaceType {
    CARAVAN,CAR,TENT;
}
