package TesteP;

import java.lang.ProcessBuilder.Redirect.Type;
import java.lang.reflect.Member;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Aula10.Book;

public class CampingService implements CampingServiceInterface {
    private String nome;
    private String endereco;
    List<Client> clientes=new ArrayList<>();
    Map<Client,List<Booking>> alugar=new HashMap<>();
    List<CampingSpace> espacoslivres=new ArrayList<>();
    
    public CampingService(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((nome == null) ? 0 : nome.hashCode());
        result = prime * result + ((endereco == null) ? 0 : endereco.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CampingService other = (CampingService) obj;
        if (nome == null) {
            if (other.nome != null)
                return false;
        } else if (!nome.equals(other.nome))
            return false;
        if (endereco == null) {
            if (other.endereco != null)
                return false;
        } else if (!endereco.equals(other.endereco))
            return false;
        return true;
    }
    @Override
    public String toString() {
        return "CampingService [nome=" + nome + ", endereco=" + endereco + "]";
    }
    @Override
    public boolean registerClient(int taxId, String name, ClientType type) {
        Client c=new Client(taxId,name,type);
        clientes.add(c);
        return true;
    }

    @Override
    public Client getClient(int taxId) {
        for(Client c: clientes){
            if(c.getContribuinte()==taxId){
                return c;
            }
        }
        return null;
    }

    @Override
    public void addCampingSpace(CampingSpace campingSpace) {
        espacoslivres.add(campingSpace);
    }
    @Override
    public void addCampingSpaces(Collection<CampingSpace> campingSpaces) {
        espacoslivres.addAll(campingSpaces);
    }
    @Override  //ver a disponibilidade de um espaco que foi adicionado aos espacos 
    public boolean checkAvailability(CampingSpace campingSpace, LocalDate startDate, LocalDate endDate) {
            for(CampingSpace i: espacoslivres){
                if(i==campingSpace){ 
                    return false;
                }
            }
        return false;
    }
    @Override
    public List<CampingSpace> findAvailableCampingSpaces(SpaceType spaceType, LocalDate fromDate, int duration,
            int[] minDimensions) {
        List<CampingSpace> espacosdisponiveis= new ArrayList<>();
        for(CampingSpace espaco: espacoslivres){
            if(espaco.getDimensoes()[0]>=minDimensions[0] && espaco.getDimensoes()[1]>=minDimensions[1]){
                espacosdisponiveis.add(espaco);
            }
        }
        return espacosdisponiveis; 
    }
    @Override
    public boolean bookCampingSpace(Client client, CampingSpace campingSpace, LocalDate startDate, int duration) {
        List<Booking> reservas= new ArrayList<>();
        Booking b=new Booking(startDate,startDate.plusDays(duration),campingSpace);
        if( client.getTipo().equals("Member")){
            reservas.add(b);
            alugar.put(client,reservas);
            return true;
        }else{
            return false;
        }
        
    }
    @Override
    public double calculateTotalCost(CampingSpace campingSpace, int duration) {
        double preco=0;
        for(CampingSpace espaco: espacoslivres){
            if(espaco.getTipo()==campingSpace.getTipo()){
                preco=espaco.getPrice()*duration;
            }
        }
        return preco;
        
    }
    @Override
    public List<String> listBookings() {
        List<String> lista=new ArrayList<>();
        for(List<Booking> b : alugar.values()){
            lista.add(b.toString());
        }
        return lista;
        
    }
    @Override
    public List<String> listBookings(SpaceType spaceType) {
        List<String> lista=new ArrayList<>();
        for(Booking b: alugar.values()){
            if(b.getTipo()==spaceType){
                lista.add(b.toString());
            }
        }

        
    }
    


}
