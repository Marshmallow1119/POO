package TesteP;

public class TentSpace extends CaravanSpace {

    public TentSpace(String localizaçao, int[] dimensoes, double price) {
        super(localizaçao, dimensoes, price);
        this.setDuracao(10);
    }
    

}
